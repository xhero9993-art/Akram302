#pragma once
#include "include/includes.h"
#include "game.h"
#include "game/Ruleset.h"
#include "imgui/inc/8bp.h"
#include "mod/keylogin.h"
#include "oxorany/oxorany.h"
#include <EGL/egl.h>
#include <EGL/eglext.h>
#include <GLES3/gl3.h>
#include <sys/system_properties.h>
#include <ctime>
#include <cmath>
#include <chrono>
#include <map>
#include <string>
#include <thread>
#include <Vector/Vectors.h>
#include <imgui/imgui.h>
#include "icons/icons.h"

using namespace ImGui;
using namespace std;



static inline const char* L(const char* en, const char* ar);

#ifndef PI
#define PI 3.14159265358979323846f
#endif

#ifndef ImGuiWindowFlags_NoBackground
#define ImGuiWindowFlags_NoBackground 0
#endif


// Smooth animated RGB accent used by the whole custom menu.
// One complete rainbow cycle takes about 6 seconds.
static inline ImVec4 RGBAccent(float alpha = 1.0f) {
    float h = fmodf((float)ImGui::GetTime() / 6.0f, 1.0f);
    float r = fabsf(h * 6.0f - 3.0f) - 1.0f;
    float g = 2.0f - fabsf(h * 6.0f - 2.0f);
    float b = 2.0f - fabsf(h * 6.0f - 4.0f);
    r = ImClamp(r, 0.0f, 1.0f);
    g = ImClamp(g, 0.0f, 1.0f);
    b = ImClamp(b, 0.0f, 1.0f);
    return ImVec4(r, g, b, alpha);
}

static inline ImU32 RGBAccentU32(float alpha = 1.0f) {
    return ImGui::ColorConvertFloat4ToU32(RGBAccent(alpha));
}

#define GOLD_BRIGHT RGBAccentU32(1.0f)
#define GOLD_MAIN   RGBAccentU32(1.0f)
#define GOLD_DIM    RGBAccentU32(0.55f)
#define GOLD_GLOW   RGBAccentU32(0.30f)

#define BLACK_DEEP  IM_COL32(10, 10, 10, 255)
#define BLACK_CARD  IM_COL32(18, 18, 18, 255)
#define BLACK_PANEL IM_COL32(24, 24, 24, 255)
#define BLACK_ITEM  IM_COL32(32, 32, 32, 255)

#define GREY_TEXT   IM_COL32(160, 150, 120, 255)

#define GOLD_VEC4      RGBAccent(1.0f)
#define GOLD_DIM_VEC4  RGBAccent(0.55f)
#define GREY_GOLD_VEC4 ImVec4(0.63f, 0.59f, 0.47f, 1.0f)

struct MenuState {
    bool isOpen = false;
    int currentTab = 0;
    float sidebarWidth = 750.0f;
    float animProgress = 0.0f;
    float menuAlpha = 0.0f;
    float menuScale = 0.9f;

    ImVec4 accentColor = ImVec4(
        0.83f,
        0.67f,
        0.16f,
        1.0f
    );
};

static MenuState g_menu;

static const int64_t EXPIRY_TS = 1789636484LL;

static bool DEBUG_BYPASS_LOGIN = true;

static float EaseOutBack(float x) {
    const float c1 = 1.70158f;
    const float c3 = c1 + 1.0f;

    return 1.0f
        + c3 * powf(x - 1.0f, 3.0f)
        + c1 * powf(x - 1.0f, 2.0f);
}

static float EaseOutQuart(float x) {
    return 1.0f - powf(1.0f - x, 4.0f);
}

static void DrawGradientRect(
    ImDrawList* dl,
    ImVec2 p1,
    ImVec2 p2,
    ImU32 col1,
    ImU32 col2,
    bool horizontal = true
) {
    if (horizontal) {
        dl->AddRectFilledMultiColor(
            p1,
            p2,
            col1,
            col2,
            col2,
            col1
        );
    } else {
        dl->AddRectFilledMultiColor(
            p1,
            p2,
            col1,
            col1,
            col2,
            col2
        );
    }
}


static void DrawGoldLine(
    ImDrawList* dl,
    ImVec2 p1,
    ImVec2 p2,
    float thickness = 1.5f
) {
    dl->AddLine(p1, p2, GOLD_DIM, thickness);
}


static bool SidebarButton(
    const char* label,
    GLuint iconTex,
    bool selected,
    float width
) {
    ImGuiWindow* window = GetCurrentWindow();

    if (window->SkipItems) {
        return false;
    }

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;

    const ImGuiID id = window->GetID(label);

    float iconSize = 60.0f;
    float vPad = 10.0f;

    float btnH =
        vPad
        + iconSize
        + 4.0f
        + g.FontSize
        + vPad;

    ImVec2 pos = window->DC.CursorPos;
    ImVec2 size = ImVec2(width, btnH);

    const ImRect bb(pos, pos + size);

    ItemSize(size, style.FramePadding.y);

    if (!ItemAdd(bb, id)) {
        return false;
    }

    bool hovered = false;
    bool held    = false;

    bool pressed = ButtonBehavior(
        bb,
        id,
        &hovered,
        &held
    );

    ImDrawList* dl = window->DrawList;

    
    if (hovered && !selected) {
        dl->AddRectFilled(
            bb.Min,
            bb.Max,
            IM_COL32(212, 170, 40, 25),
            10.0f
        );
    }

    float iconBgPad = 6.0f;

    float iconBgSize =
        iconSize + iconBgPad * 2.0f;

    ImVec2 iconCenter = ImVec2(
        bb.Min.x + width * 0.5f,
        bb.Min.y + vPad + iconSize * 0.5f
    );

    
    if (selected) {


        dl->AddRectFilled(
            ImVec2(
                iconCenter.x - iconBgSize * 0.5f - 3.0f,
                iconCenter.y - iconBgSize * 0.5f - 3.0f
            ),
            ImVec2(
                iconCenter.x + iconBgSize * 0.5f + 3.0f,
                iconCenter.y + iconBgSize * 0.5f + 3.0f
            ),
            GOLD_GLOW,
            15.0f
        );


        dl->AddRectFilledMultiColor(
            ImVec2(
                iconCenter.x - iconBgSize * 0.5f,
                iconCenter.y - iconBgSize * 0.5f
            ),
            ImVec2(
                iconCenter.x + iconBgSize * 0.5f,
                iconCenter.y + iconBgSize * 0.5f
            ),
            GOLD_MAIN,
            GOLD_BRIGHT,
            GOLD_DIM,
            GOLD_MAIN
        );


        dl->AddRect(
            ImVec2(
                iconCenter.x - iconBgSize * 0.5f,
                iconCenter.y - iconBgSize * 0.5f
            ),
            ImVec2(
                iconCenter.x + iconBgSize * 0.5f,
                iconCenter.y + iconBgSize * 0.5f
            ),
            GOLD_BRIGHT,
            12.0f,
            0,
            1.2f
        );
    }


    if (iconTex) {

        ImVec2 iconMin = ImVec2(
            iconCenter.x - iconSize * 0.5f,
            iconCenter.y - iconSize * 0.5f
        );

        ImVec2 iconMax = ImVec2(
            iconCenter.x + iconSize * 0.5f,
            iconCenter.y + iconSize * 0.5f
        );

        dl->AddImage(
            (void*)(intptr_t)iconTex,
            iconMin,
            iconMax,
            ImVec2(0, 0),
            ImVec2(1, 1)
        );
    }


    ImVec2 labelSize = CalcTextSize(label);

    ImVec2 textPos = ImVec2(
        bb.Min.x + (width - labelSize.x) * 0.5f,
        bb.Min.y + vPad + iconSize + 4.0f
    );

    ImU32 textCol =
        selected
        ? GOLD_BRIGHT
        : GREY_TEXT;

    dl->AddText(
        textPos,
        textCol,
        label
    );

    return pressed;
}


static bool ToggleSwitch(
    const char* label,
    bool* v
) {
    ImGuiWindow* window = GetCurrentWindow();

    if (window->SkipItems) {
        return false;
    }

    ImGuiContext& g = *GImGui;
    const ImGuiStyle& style = g.Style;

    const ImGuiID id = window->GetID(label);

    float scale = 1.5f;

    float height = 32.0f * scale;
    float width = 56.0f * scale;

    float radius = height * 0.5f;

    ImVec2 textSize = CalcTextSize(label);

    ImVec2 pos = window->DC.CursorPos;

    ImVec2 size = ImVec2(
        GetContentRegionAvail().x,
        ImMax(height, textSize.y)
        + style.FramePadding.y * 2.0f
        + 10.0f
    );

    const ImRect bb(pos, pos + size);

    ItemSize(size, style.FramePadding.y);

    if (!ItemAdd(bb, id)) {
        return false;
    }

    bool hovered = false;
    bool held    = false;

    bool pressed = ButtonBehavior(
        bb,
        id,
        &hovered,
        &held
    );

    if (pressed) {
        *v = !(*v);
    }

    static std::map<ImGuiID, float> switchAnim;

    float& animT = switchAnim[id];

    float targetT = *v ? 1.0f : 0.0f;

    animT +=
        (targetT - animT)
        * g.IO.DeltaTime
        * 14.0f;

    ImDrawList* dl = window->DrawList;

    if (hovered) {
        dl->AddRectFilled(
            bb.Min,
            bb.Max,
            IM_COL32(212, 170, 40, 30),
            10.0f
        );
    }

    ImVec2 togglePos = ImVec2(
        bb.Max.x - width - 15.0f,
        bb.Min.y + (size.y - height) * 0.5f
    );

    ImVec2 toggleEnd = ImVec2(
        togglePos.x + width,
        togglePos.y + height
    );

    ImVec4 offColor =
        ImVec4(0.18f, 0.18f, 0.18f, 1.0f);

    ImVec4 onColor = GOLD_VEC4;

    ImVec4 bgColorV =
        ImLerp(offColor, onColor, animT);

    dl->AddRectFilled(
        togglePos,
        toggleEnd,
        ImColor(bgColorV),
        radius
    );

    if (animT > 0.1f) {
        dl->AddRect(
            togglePos,
            toggleEnd,
            IM_COL32(
                255,
                210,
                60,
                (int)(animT * 180.0f)
            ),
            radius,
            0,
            1.2f
        );
    }

    float knobX =
        togglePos.x
        + radius
        + (width - height) * animT;

    float knobY =
        togglePos.y + radius;

    float knobR =
        radius - 4.0f;


    dl->AddCircleFilled(
        ImVec2(knobX + 1.5f, knobY + 1.5f),
        knobR + 2.0f,
        IM_COL32(0, 0, 0, 60)
    );


    dl->AddCircleFilled(
        ImVec2(knobX, knobY),
        knobR,
        IM_COL32(255, 255, 255, 255)
    );

    if (animT > 0.5f) {
        dl->AddCircle(
            ImVec2(knobX, knobY),
            knobR,
            GOLD_MAIN,
            0,
            1.5f
        );
    }


    dl->AddText(
        ImVec2(
            bb.Min.x + 15.0f,
            bb.Min.y + (size.y - textSize.y) * 0.5f
        ),
        IM_COL32(220, 205, 160, 255),
        label
    );

    return pressed;
}


static bool g_aqCounting     = false;
static bool g_aqLockout      = false;  

static std::chrono::steady_clock::time_point g_aqLastCall;
static std::chrono::steady_clock::time_point g_aqCountdownStart;
static std::chrono::steady_clock::time_point g_aqLockoutStart;

static bool IsExpired() {
    return (int64_t)time(nullptr) >= EXPIRY_TS;
}


INLINE void DrawExpired(ImGuiIO& io) {
    float winW = g_menu.sidebarWidth;

    SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    SetNextWindowSize(ImVec2(winW, 0), ImGuiCond_Always);
    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.04f, 0.04f, 0.04f, 1.0f));
    PushStyleColor(ImGuiCol_Border,   ImVec4(0.83f, 0.67f, 0.16f, 1.0f));
    PushStyleVar(ImGuiStyleVar_WindowRounding,   20.0f);
    PushStyleVar(ImGuiStyleVar_WindowPadding,    ImVec2(30.0f, 30.0f));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.5f);

    if (Begin(O("##ExpiredWin"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
              ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings |
              ImGuiWindowFlags_AlwaysAutoResize)) {

        SetWindowFontScale(1.6f);
        ImVec2 titleSz = CalcTextSize(O("MOD EXPIRED"));
        SetCursorPosX((winW - 60.0f - titleSz.x) * 0.5f);
        TextColored(GOLD_VEC4, "%s", O("MOD EXPIRED"));
        SetWindowFontScale(1.0f);

        Dummy(ImVec2(0, 16));

        PushTextWrapPos(GetCursorPosX() + winW - 60.0f);
        TextColored(GREY_GOLD_VEC4, "%s",
            O("Beta Version Expired. Update on our Telegram @olv8pool"));
        PopTextWrapPos();

        Dummy(ImVec2(0, 10));
    }
    End();
    PopStyleVar(3);
    PopStyleColor(2);
}


static int GetAutoQueueDelay() {
    switch (persistent_int["iAutoQueue_Speed"]) {
        case 0: return 800;
        case 1: return 5000;
        default:
        case 2: return 30000;
    }
}


static int GetAutoPlayShotDelay() {
    switch (persistent_int["iAutoPlay_Speed"]) {
        case 0: return 0;     
        case 1: return 3000;  
        default:
        case 2: return 5000;  
    }
}


INLINE void DrawAutoQueue() {
    if ((!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) || DEBUG_BYPASS_LOGIN) {
        auto now = std::chrono::steady_clock::now();


        if (g_aqLockout) {
            auto lockElapsed = std::chrono::duration_cast<std::chrono::milliseconds>(
                now - g_aqLockoutStart).count();
            if (lockElapsed < 4000) return;  
            g_aqLockout  = false;
            g_aqCounting = false;
        }


        if (std::chrono::duration_cast<std::chrono::milliseconds>(now - g_aqLastCall).count() > 500)
            g_aqCounting = false;
        g_aqLastCall = now;

        if (!g_aqCounting) {
            g_aqCounting       = true;
            g_aqCountdownStart = now;
        }

        auto elapsed      = std::chrono::duration_cast<std::chrono::milliseconds>(now - g_aqCountdownStart).count();
        int  totalDelay   = GetAutoQueueDelay();
        int  remaining_ms = totalDelay - (int)elapsed;


        if (remaining_ms <= 0) {
            if (sharedMenuManager.getMenuStateId() == 13) PopMenuState(13);
            StartLastMatch();
            g_aqCounting    = false;
            g_aqLockout     = true;
            g_aqLockoutStart = now;
            return;
        }


        int displaySec = (remaining_ms / 1000) + 1;
        if (displaySec < 1) displaySec = 1;
        std::string count_str = std::to_string(displaySec);


        SetNextWindowPos(ImVec2(Width * 0.5f, Height * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
        PushStyleColor(ImGuiCol_WindowBg,  ImVec4(0.04f, 0.04f, 0.04f, 1.0f));
        PushStyleColor(ImGuiCol_Border,    ImVec4(0.83f, 0.67f, 0.16f, 1.0f));
        PushStyleVar(ImGuiStyleVar_WindowPadding,    ImVec2(40.0f, 24.0f));
        PushStyleVar(ImGuiStyleVar_WindowRounding,   28.0f);
        PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.5f);

        if (Begin(O("##AutoQueueCD"), nullptr,
                  ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
                  ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings |
                  ImGuiWindowFlags_AlwaysAutoResize)) {

            ImDrawList* dl  = GetWindowDrawList();
            ImVec2      wp  = GetWindowPos();
            ImVec2      ws  = GetWindowSize();


            dl->AddRectFilled(wp, ImVec2(wp.x + ws.x, wp.y + ws.y),
                BLACK_DEEP, 28.0f);
            dl->AddRect(wp, ImVec2(wp.x + ws.x, wp.y + ws.y),
                GOLD_MAIN, 28.0f, 0, 1.5f);


            SetWindowFontScale(4.0f);
            ImVec2 numSz = CalcTextSize(count_str.c_str());
            SetCursorPosX((ws.x - numSz.x) * 0.5f - 8.0f);
            TextColored(GOLD_VEC4, "%s", count_str.c_str());
            SetWindowFontScale(1.0f);


            float progress = 1.0f - (float)remaining_ms / (float)totalDelay;
            ImVec2 barP1 = ImVec2(wp.x + 14, wp.y + ws.y - 14);
            ImVec2 barP2 = ImVec2(wp.x + ws.x - 14, wp.y + ws.y - 8);
            dl->AddRectFilled(barP1, barP2, BLACK_ITEM, 4.0f);
            dl->AddRectFilled(barP1,
                ImVec2(barP1.x + (barP2.x - barP1.x) * progress, barP2.y),
                GOLD_MAIN, 4.0f);
        }
        End();
        PopStyleVar(3);
        PopStyleColor(2);
    }
}

#include "mod/ButtonClicker.h"

static void DrawToggleButton(bool cancelMode);


INLINE void DrawESP(ImDrawList* draw) {
    if ((!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) || DEBUG_BYPASS_LOGIN) {
        if (!sharedGameManager) return;

        UpdateScreenTable();

        sharedDirector = F(ptr, libmain + O(0x4f06288));
        if (!sharedDirector) return;

        sharedUserInfo = F(ptr, libmain + O(0x4e9feb8));
        if (!sharedUserInfo) return;

        F(bool, sharedUserInfo + 0x340) = true;

        sharedMainManager = F(ptr, libmain + O(0x4dde3e0));
        if (!sharedMainManager) return;

        sharedMenuManager = F(ptr, libmain + O(0x4dfe838));
        if (!sharedMenuManager) return;

        MainStateManager mainStateManager = sharedMainManager.mStateManager;
        if (!mainStateManager) return;
        if (!mainStateManager.isInGame()) {
            if (persistent_bool[O("bAutoQueue")]) {
                if (!sharedMenuManager.isInQueue()) DrawAutoQueue();
                DrawToggleButton(true);
            }
            return;
        }

        auto visualCue = sharedGameManager.mVisualCue();

        Ball::Classification myclass = sharedGameManager.getPlayerClassification();

        Table table = sharedGameManager.mTable;
        if (!table) return;

        auto tableProperties = table.mTableProperties();
        if (!tableProperties) return;

        auto& pockets = tableProperties.mPockets();

        GameStateManager gameStateManager = sharedGameManager.mStateManager;
        if (!gameStateManager) return;

        auto stateId = gameStateManager.getCurrentStateId();
        if (stateId == 4) gPrediction->determineShotResult(false);
        if (stateId == 6 || stateId == 7 || stateId == 8) return;

        if (persistent_bool[O("bAutoPlay")]) {
            DrawToggleButton(false);


            static std::chrono::steady_clock::time_point g_apShotTimer;
            static bool  g_apTimerActive  = false;
            static int   g_apPrevStateId  = -1;


            if (g_apPrevStateId != stateId) {
                g_apShotTimer     = std::chrono::steady_clock::now();
                g_apTimerActive   = true;
                g_apPrevStateId   = stateId;
            }

            if (g_apTimerActive) {
                int  shotDelay = GetAutoPlayShotDelay();
                long elapsed   = (long)std::chrono::duration_cast<std::chrono::milliseconds>(
                    std::chrono::steady_clock::now() - g_apShotTimer).count();

                if (elapsed >= shotDelay) {

                    AutoPlay::Update();
                }

            }
        }

        if (persistent_bool[O("bESP_DrawPocketsShotState")]) {
            for (int i = 0; i < 6; i++) {
                if (Prediction::pocketStatus[i]) {
                    auto screenPos = WorldToScreen(pockets[i]);
                    draw->AddCircle(ImVec2(screenPos.x, screenPos.y), 30, GREEN, 0, 5.f);
                }
            }
        }

        if (persistent_bool[O("bESP_DrawPredictionLine")]) {
            for (int i = 0; i < gPrediction->guiData.ballsCount; i++) {
                auto& ball = gPrediction->guiData.balls[i];

                if (ball.initialPosition != ball.predictedPosition) {
                    ImVec2 lastPos{};
                    float lineThick = (float)persistent_int[O("iLineThickness")];
                    if (lineThick < 1.f) lineThick = 1.f;
                    int lineStyleP = persistent_int["iLineStyle"];
                    for (int j = 1; j < (int)ball.positions.size(); j++) {
                        auto point = WorldToScreen(ball.positions[j]);
                        if (lastPos.x || lastPos.y) {
                            if (lineStyleP == 1) {
                                
                                
                                
                                float dx = point.x - lastPos.x;
                                float dy = point.y - lastPos.y;
                                float segLen = sqrtf(dx * dx + dy * dy);
                                if (segLen < 0.0001f) { lastPos = point; continue; }
                                float dashLen = lineThick * 3.0f + 5.0f;
                                float gapLen  = lineThick * 2.0f + 4.0f;
                                float stepLen = dashLen + gapLen;
                                int   steps   = (int)(segLen / stepLen);
                                if (steps < 1) steps = 1;
                                float ux = dx / segLen;
                                float uy = dy / segLen;
                                ImU32 colBall = colors[i];
                                for (int k = 0; k <= steps; k++) {
                                    float t0 = (float)k * stepLen;
                                    float t1 = t0 + dashLen;
                                    if (t0 >= segLen) break;
                                    if (t1 > segLen) t1 = segLen;
                                    ImVec2 a(lastPos.x + ux * t0, lastPos.y + uy * t0);
                                    ImVec2 b(lastPos.x + ux * t1, lastPos.y + uy * t1);
                                    draw->AddLine(a, b, colBall, lineThick);
                                }
                            } else {
                                draw->AddLine(lastPos, point, colors[i], lineThick);
                            }
                        }
                        lastPos = point;
                    }
                }
            }
        }

        if (persistent_bool[O("bESP_DrawPredictionLine")]) {
            for (int i = 0; i < gPrediction->guiData.ballsCount; i++) {
                auto& ball = gPrediction->guiData.balls[i];

                if (ball.initialPosition != ball.predictedPosition) {
                    float circleR = (float)persistent_int[O("iLineThickness")] + 1.f;
                    if (circleR < 2.f) circleR = 2.f;
                    draw->AddCircleFilled(WorldToScreen(ball.initialPosition), circleR, colors[i]);
                    draw->AddCircleFilled(WorldToScreen(ball.predictedPosition), 16, colors[i]);
                }
            }
        }
    }
}


static void DrawSidebar(float sidebarW) {
    static GLuint draw_icon_tex = LoadTextureFromMemory(draw_icon_png, draw_icon_png_len);
    static GLuint play_icon_tex = LoadTextureFromMemory(play_icon_png, play_icon_png_len);
    static GLuint q_icon_tex    = LoadTextureFromMemory(q_icon_png,    q_icon_png_len);
    static GLuint user_icon_tex = LoadTextureFromMemory(user_icon_png, user_icon_png_len);

    ImGuiContext& g  = *GImGui;
    ImDrawList*   dl = GetWindowDrawList();
    ImVec2        wp = GetWindowPos();

    float closeSize = 35.0f;
    float closeBtnW = 70.0f;
    float tabsW     = sidebarW - closeBtnW;
    float btnW      = tabsW / 4.0f;
    float marginB   = 12.0f;

    dl->ChannelsSplit(2);
    dl->ChannelsSetCurrent(1);

    BeginGroup();
    SetCursorPos(ImVec2(0.0f, 0.0f));
    if (SidebarButton(L("Draw", "ﻢﺳﺮﻟﺍ"),  draw_icon_tex, g_menu.currentTab == 0, btnW)) g_menu.currentTab = 0;
    SameLine(0, 0);
    if (SidebarButton(L("Play", "ﻲﺋﺎﻘﻠﺘﻟﺍ"),  play_icon_tex, g_menu.currentTab == 1, btnW)) g_menu.currentTab = 1;
    SameLine(0, 0);
    if (SidebarButton(L("Queue", "ﻝﻮﺧﺪﻟﺍ"), q_icon_tex,    g_menu.currentTab == 2, btnW)) g_menu.currentTab = 2;
    SameLine(0, 0);
    if (SidebarButton(L("User", "ﺕﺎﻣﻮﻠﻌﻤﻟﺍ"),  user_icon_tex, g_menu.currentTab == 3, btnW)) g_menu.currentTab = 3;
    EndGroup();

    float sidebarH = GetItemRectMax().y - wp.y;

    dl->ChannelsSetCurrent(0);


    dl->AddRectFilled(wp, ImVec2(wp.x + sidebarW, wp.y + sidebarH), BLACK_PANEL, 30.0f);

    dl->AddLine(
        ImVec2(wp.x + 12, wp.y + sidebarH - 1),
        ImVec2(wp.x + sidebarW - 12, wp.y + sidebarH - 1),
        GOLD_DIM, 1.0f
    );

    dl->ChannelsMerge();


    float sepX       = wp.x + sidebarW - closeBtnW;
    float sepCenterY = wp.y + sidebarH * 0.5f;
    float sepHalfH   = sidebarH * 0.28f;
    dl->AddLine(
        ImVec2(sepX, sepCenterY - sepHalfH),
        ImVec2(sepX, sepCenterY + sepHalfH),
        GOLD_DIM, 1.2f
    );


    float closePosX = (sidebarW - closeBtnW) + (closeBtnW - closeSize) * 0.5f;
    float closePosY = (sidebarH - closeSize) * 0.5f;
    SetCursorPos(ImVec2(closePosX, closePosY));
    {
        ImGuiWindow* win = GetCurrentWindow();
        ImGuiID closeId  = win->GetID(O("##CloseMenu"));
        ImVec2 closePos  = win->DC.CursorPos;
        ImRect closeBb(closePos, closePos + ImVec2(closeSize, closeSize));
        ItemSize(ImVec2(closeSize, closeSize), g.Style.FramePadding.y);
        ItemAdd(closeBb, closeId);
        bool closeHovered = false, closeHeld = false;
        bool closePressed = ButtonBehavior(closeBb, closeId, &closeHovered, &closeHeld);
        if (closePressed) g_menu.isOpen = false;

        float xCX = closeBb.Min.x + closeSize * 0.5f;
        float xCY = closeBb.Min.y + closeSize * 0.5f;
        float xH  = closeSize * 0.32f;
        ImU32 xCol = closeHovered ? GOLD_BRIGHT : GOLD_DIM;
        dl->AddLine(ImVec2(xCX - xH, xCY - xH), ImVec2(xCX + xH, xCY + xH), xCol, 2.2f);
        dl->AddLine(ImVec2(xCX + xH, xCY - xH), ImVec2(xCX - xH, xCY + xH), xCol, 2.2f);
    }

    SetCursorPos(ImVec2(0.0f, sidebarH));
    Dummy(ImVec2(sidebarW, marginB));
}


static std::string ReadNSString(ptr str) {
    if (!str) return "null";
    int32_t len = F(int32_t, str + 0x10);
    if (len <= 0 || len > 512) return "?";
    std::string result;
    result.reserve(len);
    for (int32_t i = 0; i < len; i++) {
        uint16_t ch = F(uint16_t, str + 0x14 + i * 2);
        result += (ch > 0 && ch < 128) ? (char)ch : '?';
    }
    return result;
}




static inline const char* L(const char* en, const char* ar) {
    return persistent_int["iLang"] == 1 ? ar : en;
}

static const ImWchar* GetArabicGlyphRanges() {
    static const ImWchar ranges[] = {
        0x0020, 0x00FF, 
        0x0600, 0x06FF, 
        0x0750, 0x077F, 
        0xFB50, 0xFDFF, 
        0xFE70, 0xFEFF, 
        0,
    };
    return ranges;
}

static float g_sideBtnsY      = 0.0f;
static float g_toggleRotAngle = 0.0f;
static bool  g_autoPlayCalculating = false;


static void svConfig_Save() {
    std::string path = O("/data/user/0/") + PACKAGE_NAME + O("/files/svConfig.txt");
    FILE* f = fopen(path.c_str(), O("w"));
    if (!f) return;
    fprintf(f, O("iLineThickness=%d\n"),    persistent_int[O("iLineThickness")]);
    fprintf(f, O("iMenuSizeOffset=%d\n"),   persistent_int[O("iMenuSizeOffset")]);
    fprintf(f, O("iAutoQueue_Speed=%d\n"),  persistent_int["iAutoQueue_Speed"]);
    fprintf(f, O("iAutoPlay_Speed=%d\n"),   persistent_int["iAutoPlay_Speed"]);
    fprintf(f, O("iLineStyle=%d\n"),       persistent_int["iLineStyle"]);
    fprintf(f, O("iLang=%d\n"),            persistent_int["iLang"]);
    fclose(f);
}
static void svConfig_Load() {
    std::string path = O("/data/user/0/") + PACKAGE_NAME + O("/files/svConfig.txt");
    FILE* f = fopen(path.c_str(), O("r"));
    if (!f) return;
    char line[64];
    while (fgets(line, sizeof(line), f)) {
        int v = 0;
        if (sscanf(line, O("iLineThickness=%d"),   &v) == 1) { persistent_int[O("iLineThickness")]  = v; continue; }
        if (sscanf(line, O("iMenuSizeOffset=%d"),  &v) == 1) { persistent_int[O("iMenuSizeOffset")] = v; continue; }
        if (sscanf(line, O("iAutoQueue_Speed=%d"), &v) == 1) { persistent_int["iAutoQueue_Speed"]   = v; continue; }
        if (sscanf(line, O("iAutoPlay_Speed=%d"),  &v) == 1) { persistent_int["iAutoPlay_Speed"]    = v; continue; }
        if (sscanf(line, O("iLineStyle=%d"),       &v) == 1) { persistent_int["iLineStyle"]         = v; continue; }
        if (sscanf(line, O("iLang=%d"),            &v) == 1) { persistent_int["iLang"]              = v; }
    }
    fclose(f);
}


static void DrawCalculating() {
    SetNextWindowPos(ImVec2(Width * 0.5f, Height * 0.5f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));
    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.04f, 0.04f, 0.04f, 1.0f));
    PushStyleColor(ImGuiCol_Border,   ImVec4(0.83f, 0.67f, 0.16f, 1.0f));
    PushStyleVar(ImGuiStyleVar_WindowRounding,   18.0f);
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.5f);

    if (Begin(O("##CalcOverlay"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
              ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
              ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoInputs)) {

        SetWindowFontScale(1.4f);
        TextColored(GOLD_VEC4, O("CALCULATING..."));
        SetWindowFontScale(1.0f);
    }
    End();
    PopStyleVar(2);
    PopStyleColor(2);
}


static void DrawContentArea(float winW, float winH) {
    bool need_save = false;

    ImDrawList* dl  = GetWindowDrawList();
    ImVec2      wp  = GetWindowPos();

    float startY   = GetCursorPosY();
    float contentW = winW;


    dl->AddRectFilled(
        ImVec2(wp.x, wp.y + startY),
        ImVec2(wp.x + contentW, wp.y + winH),
        BLACK_CARD, 20.0f
    );

    const char* tabTitles[] = {
        L("Draw Settings", "ﻢﺳﺮﻟﺍ"),
        L("Auto Play", "ﻲﺋﺎﻘﻠﺘﻟﺍ ﺐﻌﻟﺍ"),
        L("Auto Queue", "ﻲﺋﺎﻘﻠﺘﻟﺍ ﻝﻮﺧﺪﻟﺍ"),
        L("User", "ﻡﺪﺨﺘﺴﻤﻟﺍ")
    };

    const char* currentTitle = tabTitles[g_menu.currentTab];
    float titlePadT = 18.0f;
    float titlePadB = 14.0f;

    SetWindowFontScale(1.15f);
    ImVec2 ts = CalcTextSize(currentTitle);

    float centeredX = (contentW - ts.x) * 0.5f;
    SetCursorPos(ImVec2(centeredX, startY + titlePadT));


    TextColored(GOLD_VEC4, "%s", currentTitle);
    SetWindowFontScale(1.0f);


    float lineY = startY + titlePadT + ts.y + titlePadB;

    dl->AddLine(
        ImVec2(wp.x + 15.0f, wp.y + lineY),
        ImVec2(wp.x + contentW - 15.0f, wp.y + lineY),
        GOLD_GLOW, 3.0f
    );

    dl->AddLine(
        ImVec2(wp.x + 15.0f, wp.y + lineY),
        ImVec2(wp.x + contentW - 15.0f, wp.y + lineY),
        GOLD_DIM, 1.2f
    );

    float headerH = (lineY - startY) + 10.0f;
    SetCursorPos(ImVec2(10.0f, startY + headerH));

    PushStyleColor(ImGuiCol_ChildBg, ImVec4(0, 0, 0, 0));
    BeginChild(O("##ContentArea"), ImVec2(contentW - 20.0f, winH - startY - headerH - 10.0f), false);

    switch (g_menu.currentTab) {

        
        case 0: {   
            Dummy(ImVec2(0, 10));

            
            TextColored(GREY_GOLD_VEC4, L("Language", "ﻪﻐﻟﺍ"));
            Dummy(ImVec2(0, 8));
            {
                int& lang = persistent_int["iLang"];
                if (lang < 0 || lang > 1) lang = 0;
                static const char* langLabels[2] = { "English", "ﻪﻴﺑﺮﻌﻟﺍ" };
                float availLG = GetContentRegionAvail().x;
                float gapLG   = 10.0f;
                float bWLG    = (availLG - gapLG) / 2.0f;
                float bHLG    = 56.0f;
                PushStyleVar(ImGuiStyleVar_FrameRounding, 12.0f);
                for (int i = 0; i < 2; i++) {
                    if (i > 0) SameLine(0, gapLG);
                    bool isSel = (lang == i);
                    if (isSel) {
                        PushStyleColor(ImGuiCol_Button,        GOLD_VEC4);
                        PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.0f, 0.85f, 0.25f, 1.0f));
                        PushStyleColor(ImGuiCol_ButtonActive,  GOLD_DIM_VEC4);
                        PushStyleColor(ImGuiCol_Text,          ImVec4(0.05f, 0.05f, 0.05f, 1.0f));
                    } else {
                        PushStyleColor(ImGuiCol_Button,        ImVec4(0.12f, 0.12f, 0.12f, 1.0f));
                        PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.20f, 0.18f, 0.08f, 1.0f));
                        PushStyleColor(ImGuiCol_ButtonActive,  GOLD_DIM_VEC4);
                        PushStyleColor(ImGuiCol_Text,          GREY_GOLD_VEC4);
                    }
                    if (Button(langLabels[i], ImVec2(bWLG, bHLG))) {
                        lang = i;
                        need_save = true;
                    }
                    if (isSel) {
                        ImVec2 rMin = GetItemRectMin();
                        ImVec2 rMax = GetItemRectMax();
                        GetWindowDrawList()->AddRect(rMin, rMax, GOLD_BRIGHT, 12.0f, 0, 2.0f);
                    }
                    PopStyleColor(4);
                }
                PopStyleVar();
            }
            Dummy(ImVec2(0, 18));

            need_save |= ToggleSwitch(L("Draw Lines", "ﻁﻮﻄﺨﻟﺍ ﻢﺳﺭ"),   &persistent_bool[O("bESP_DrawPredictionLine")]);
            need_save |= ToggleSwitch(L("Draw Pockets", "ﺏﻮﻴﺠﻟﺍ ﻢﺳﺭ"), &persistent_bool[O("bESP_DrawPocketsShotState")]);

            Dummy(ImVec2(0, 16));
            TextColored(GREY_GOLD_VEC4, L("Line Thickness", "ﻂﺨﻟﺍ ﺔﻛﺎﻤﺳ"));
            Dummy(ImVec2(0, 8));
            {
                if (persistent_int[O("iLineThickness")] < 1) persistent_int[O("iLineThickness")] = 4;
                PushStyleVar(ImGuiStyleVar_FrameRounding, 10.0f);
                PushStyleVar(ImGuiStyleVar_GrabRounding,  10.0f);
                PushStyleColor(ImGuiCol_FrameBg,          ImVec4(0.10f, 0.10f, 0.10f, 1.0f));
                PushStyleColor(ImGuiCol_FrameBgHovered,   ImVec4(0.14f, 0.14f, 0.14f, 1.0f));
                PushStyleColor(ImGuiCol_SliderGrab,       GOLD_VEC4);
                PushStyleColor(ImGuiCol_SliderGrabActive, ImVec4(1.0f, 0.85f, 0.2f, 1.0f));
                SetNextItemWidth(GetContentRegionAvail().x);
                need_save |= SliderInt(O("##lineThick"), &persistent_int[O("iLineThickness")], 1, 10, "%d");
                PopStyleColor(4);
                PopStyleVar(2);
            }

            Dummy(ImVec2(0, 16));
            TextColored(GREY_GOLD_VEC4, L("Line Style", "ﻂﺨﻟﺍ ﻂﻤﻧ"));
            Dummy(ImVec2(0, 8));
            {
                int& lineStyle = persistent_int["iLineStyle"];
                if (lineStyle < 0 || lineStyle > 1) lineStyle = 0;

                static const char* styleLabels[2] = { "SOLID", "DOTTED" };

                float availLS = GetContentRegionAvail().x;
                float gapLS   = 10.0f;
                float bWLS    = (availLS - gapLS) / 2.0f;
                float bHLS    = 56.0f;

                PushStyleVar(ImGuiStyleVar_FrameRounding, 12.0f);
                for (int i = 0; i < 2; i++) {
                    if (i > 0) SameLine(0, gapLS);
                    bool isSel = (lineStyle == i);
                    if (isSel) {
                        PushStyleColor(ImGuiCol_Button,        GOLD_VEC4);
                        PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.0f, 0.85f, 0.25f, 1.0f));
                        PushStyleColor(ImGuiCol_ButtonActive,  GOLD_DIM_VEC4);
                        PushStyleColor(ImGuiCol_Text,          ImVec4(0.05f, 0.05f, 0.05f, 1.0f));
                    } else {
                        PushStyleColor(ImGuiCol_Button,        ImVec4(0.12f, 0.12f, 0.12f, 1.0f));
                        PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.20f, 0.18f, 0.08f, 1.0f));
                        PushStyleColor(ImGuiCol_ButtonActive,  GOLD_DIM_VEC4);
                        PushStyleColor(ImGuiCol_Text,          GREY_GOLD_VEC4);
                    }
                    if (Button(styleLabels[i], ImVec2(bWLS, bHLS))) {
                        lineStyle = i;
                        need_save = true;
                    }
                    if (isSel) {
                        ImVec2 rMin = GetItemRectMin();
                        ImVec2 rMax = GetItemRectMax();
                        GetWindowDrawList()->AddRect(rMin, rMax, GOLD_BRIGHT, 12.0f, 0, 2.0f);
                    }
                    PopStyleColor(4);
                }
                PopStyleVar();
            }

            Dummy(ImVec2(0, 16));
            TextColored(GREY_GOLD_VEC4, L("Fix Menu Size", "ﺔﻤﺋﺎﻘﻟﺍ ﻢﺠﺣ"));
            Dummy(ImVec2(0, 8));
            {
                PushStyleVar(ImGuiStyleVar_FrameRounding, 10.0f);
                PushStyleVar(ImGuiStyleVar_GrabRounding,  10.0f);
                PushStyleColor(ImGuiCol_FrameBg,          ImVec4(0.10f, 0.10f, 0.10f, 1.0f));
                PushStyleColor(ImGuiCol_FrameBgHovered,   ImVec4(0.14f, 0.14f, 0.14f, 1.0f));
                PushStyleColor(ImGuiCol_SliderGrab,       GOLD_VEC4);
                PushStyleColor(ImGuiCol_SliderGrabActive, ImVec4(1.0f, 0.85f, 0.2f, 1.0f));
                SetNextItemWidth(GetContentRegionAvail().x);
                int& menuSz = persistent_int[O("iMenuSizeOffset")];
                bool changed = SliderInt(O("##menuSize"), &menuSz, -10, 10,
                    menuSz == 0 ? O("Normal") : "%d");
                need_save |= changed;
                PopStyleColor(4);
                PopStyleVar(2);
            }

            Dummy(ImVec2(0, 20));
            {

                PushStyleVar(ImGuiStyleVar_FrameRounding, 12.0f);
                PushStyleColor(ImGuiCol_Button,        GOLD_DIM_VEC4);
                PushStyleColor(ImGuiCol_ButtonHovered, GOLD_VEC4);
                PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.45f, 0.34f, 0.04f, 1.0f));
                PushStyleColor(ImGuiCol_Text,          ImVec4(0.0f, 0.0f, 0.0f, 1.0f));
                if (Button(L("Save Config", "ﺕﺍﺪﻋﻹﺍ ﻆﻔﺣ"), ImVec2(GetContentRegionAvail().x, 55.0f))) {
                    svConfig_Save();
                }
                PopStyleColor(4);
                PopStyleVar();
            }

            Dummy(ImVec2(0, 16));
            TextColored(GREY_GOLD_VEC4, L("Hide All During Screen Capture", "ﺔﺷﺎﺸﻟﺍ ﺮﻳﻮﺼﺗ ﺀﺎﻨﺛﺃ ﻞﻜﻟﺍ ﺀﺎﻔﺧﺇ"));
            Dummy(ImVec2(0, 8));
            need_save |= ToggleSwitch(L("Hide All For Capture", "ﺮﻳﻮﺼﺘﻠﻟ ﻞﻜﻟﺍ ﺀﺎﻔﺧﺇ"), &persistent_bool[O("bHideAllCapture")]);
            Dummy(ImVec2(0, 6));
            TextColored(GREY_GOLD_VEC4, L("Tap top-left corner to disable", "ﺀﺎﻐﻟﻺﻟ ﻯﺮﺴﻴﻟﺍ ﺔﻳﻮﻠﻌﻟﺍ ﺔﻳﻭﺍﺰﻟﺍ ﺮﻘﻧﺍ"));
            break;
        }

        
        case 1: {   
            Dummy(ImVec2(0, 10));
            need_save |= ToggleSwitch(L("Enable AutoPlay", "ﻲﺋﺎﻘﻠﺘﻟﺍ ﺐﻌﻠﻟﺍ ﻞﻴﻌﻔﺗ"), &persistent_bool[O("bAutoPlay")]);
            Dummy(ImVec2(0, 20));
            TextColored(GREY_GOLD_VEC4, L("Auto Play Will AutoMatically", "ًﺎﻴﺋﺎﻘﻠﺗ ﻡﻮﻘﻴﺳ ﻲﺋﺎﻘﻠﺘﻟﺍ ﺐﻌﻠﻟﺍ"));
            TextColored(GREY_GOLD_VEC4, L("Aim And Shoot For You", "ﻚﻨﻋ ﺔﺑﺎﻴﻧ ﺏﺮﻀﻟﺍﻭ ﺐﻳﻮﺼﺘﻟﺎﺑ"));

            
            Dummy(ImVec2(0, 24));
            TextColored(GOLD_VEC4, L("Shot Timing", "ﺔﺑﺮﻀﻟﺍ ﺖﻴﻗﻮﺗ"));
            Dummy(ImVec2(0, 6));
            TextColored(GREY_GOLD_VEC4, L("Delay before AutoPlay shoots the ball", "ﺓﺮﻜﻟﺍ ﺏﺮﺿ ﻞﺒﻗ ﺮﻴﺧﺄﺘﻟﺍ"));
            Dummy(ImVec2(0, 10));
            {
                int& spd = persistent_int["iAutoPlay_Speed"];
                if (spd < 0 || spd > 2) spd = 0;

                struct SpeedBtn { const char* label; const char* sublabel; };
                static const SpeedBtn speeds[3] = {
                    { "INSTANT" },
                    { "MEDIUM" },
                    { "SLOW" },
                };

                float avail = GetContentRegionAvail().x;
                float gap   = 10.0f;
                float bW    = (avail - gap * 2.0f) / 3.0f;
                float bH    = 72.0f;

                PushStyleVar(ImGuiStyleVar_FrameRounding, 14.0f);

                for (int i = 0; i < 3; i++) {
                    if (i > 0) SameLine(0, gap);

                    bool isSel = (spd == i);

                    if (isSel) {
                        PushStyleColor(ImGuiCol_Button,        GOLD_VEC4);
                        PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(1.0f, 0.85f, 0.25f, 1.0f));
                        PushStyleColor(ImGuiCol_ButtonActive,  GOLD_DIM_VEC4);
                        PushStyleColor(ImGuiCol_Text,          ImVec4(0.05f, 0.05f, 0.05f, 1.0f));
                    } else {
                        PushStyleColor(ImGuiCol_Button,        ImVec4(0.12f, 0.12f, 0.12f, 1.0f));
                        PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.20f, 0.18f, 0.08f, 1.0f));
                        PushStyleColor(ImGuiCol_ButtonActive,  GOLD_DIM_VEC4);
                        PushStyleColor(ImGuiCol_Text,          GREY_GOLD_VEC4);
                    }

                    char btnLabel[32];
                    snprintf(btnLabel, sizeof(btnLabel), "%s\n%s", speeds[i].label, speeds[i].sublabel);

                    if (Button(btnLabel, ImVec2(bW, bH))) {
                        spd = i;
                        need_save = true;
                    }

                    if (isSel) {
                        ImVec2 rMin = GetItemRectMin();
                        ImVec2 rMax = GetItemRectMax();
                        GetWindowDrawList()->AddRect(rMin, rMax, GOLD_BRIGHT, 14.0f, 0, 2.0f);
                    }

                    PopStyleColor(4);
                }

                PopStyleVar();
            }
            break;
        }

        
        case 2: {   
            Dummy(ImVec2(0, 10));
            need_save |= ToggleSwitch(L("Enable AutoQueue", "ﻲﺋﺎﻘﻠﺘﻟﺍ ﻝﻮﺧﺪﻟﺍ ﻞﻴﻌﻔﺗ"), &persistent_bool[O("bAutoQueue")]);
            break;
        }

        
        case 3: {   
            auto DrawSectionHeader = [&](const char* title) {
                Dummy(ImVec2(0, 14));
                float avail = GetContentRegionAvail().x;
                ImVec2 p    = GetCursorScreenPos();
                float  fs   = GImGui->FontSize;
                ImVec2 tszz = CalcTextSize(title);
                float  lineY = p.y + fs * 0.5f;
                float  gap   = 8.0f;
                float  lineW = (avail - tszz.x - gap * 2.0f) * 0.5f;
                ImDrawList* dl2 = GetWindowDrawList();
                dl2->AddLine(ImVec2(p.x,                               lineY),
                             ImVec2(p.x + lineW,                       lineY), GOLD_DIM, 1.0f);
                dl2->AddLine(ImVec2(p.x + lineW + gap + tszz.x + gap, lineY),
                             ImVec2(p.x + avail,                       lineY), GOLD_DIM, 1.0f);
                SetCursorPosX(GetCursorPosX() + lineW + gap);
                TextColored(GOLD_VEC4, "%s", title);
                Dummy(ImVec2(0, 6));
            };

            auto DrawInfoRow = [&](const char* key, const char* val) {
                TextColored(GREY_GOLD_VEC4, "%s", key);
                SameLine();
                TextColored(ImVec4(0.95f, 0.88f, 0.60f, 1.0f), "%s", val);
                Dummy(ImVec2(0, 4));
            };

            DrawSectionHeader(O("System Status"));
            {
                static char s_manufacturer[PROP_VALUE_MAX] = {};
                static char s_model[PROP_VALUE_MAX] = {};
                static char s_abi[PROP_VALUE_MAX] = {};
                static char s_android[PROP_VALUE_MAX] = {};
                static bool s_props_loaded = false;

                if (!s_props_loaded) {
                    __system_property_get("ro.product.manufacturer", s_manufacturer);
                    __system_property_get("ro.product.model",        s_model);
                    __system_property_get("ro.product.cpu.abi",      s_abi);
                    __system_property_get("ro.build.version.release", s_android);
                    s_props_loaded = true;
                }

                int64_t now_ts = (int64_t)time(nullptr);
                int64_t diff   = EXPIRY_TS - now_ts;
                char expireBuf[64];
                if (diff > 0) {
                    int days  = (int)(diff / 86400);
                    int hours = (int)((diff % 86400) / 3600);
                    int mins  = (int)((diff % 3600)  / 60);
                    snprintf(expireBuf, sizeof(expireBuf), "%dd - %dh - %dm", days, hours, mins);
                } else {
                    snprintf(expireBuf, sizeof(expireBuf), "%s", O("Expired"));
                }

                DrawInfoRow(O("ManuFacturer: "), s_manufacturer);
                DrawInfoRow(O("Model: "),        s_model);
                DrawInfoRow(O("Abi: "),          s_abi);
                DrawInfoRow(O("Android: "),      s_android);
                DrawInfoRow(O("Key: "),          persistent_string["key"].c_str());
                DrawInfoRow(O("Expire: "),       expireBuf);
            }
            break;
        }
    }

    if (need_save) save_persistence();

    EndChild();
    PopStyleColor();
}


INLINE void DrawMenu(ImGuiIO& io) {
    if ((!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) || DEBUG_BYPASS_LOGIN) {
        if (is_segv_handler_active()) {
            jump_buffer_active = 1;
            if (!sigsetjmp(jump_buffer, 1)) DrawESP(GetBackgroundDrawList());
            jump_buffer_active = 0;
        }

        if (g_menu.isOpen) {
            g_menu.menuAlpha += (1.0f - g_menu.menuAlpha) * io.DeltaTime * 12.0f;
        } else {
            g_menu.menuAlpha = 0.0f;
        }

        if (g_menu.menuAlpha > 0.01f) {
            float sizeScale = 1.0f + (float)persistent_int[O("iMenuSizeOffset")] * 0.03f;
            if (sizeScale < 0.3f) sizeScale = 0.3f;
            float winW = g_menu.sidebarWidth * sizeScale;
            float winH = 560.0f * sizeScale;

            SetNextWindowSize(ImVec2(winW, winH), ImGuiCond_Always);
            SetNextWindowPos(ImVec2(Width / 2.0f, Height / 2.0f), ImGuiCond_Always, ImVec2(0.5f, 0.5f));

            PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.0f, 0.0f, 0.0f, 0.0f));
            PushStyleVar(ImGuiStyleVar_WindowRounding,   16.0f);
            PushStyleVar(ImGuiStyleVar_WindowPadding,    ImVec2(0, 0));
            PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
            PushStyleVar(ImGuiStyleVar_Alpha,            g_menu.menuAlpha);

            ImGuiWindowFlags winFlags =
                ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoTitleBar |
                ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse |
                ImGuiWindowFlags_NoResize    | ImGuiWindowFlags_NoMove;

            if (Begin(O("##MainMenu"), &g_menu.isOpen, winFlags)) {

                ImDrawList* dlm = GetWindowDrawList();
                ImVec2 wPos = GetWindowPos();
                ImVec2 wSz  = GetWindowSize();
                dlm->AddRect(wPos, ImVec2(wPos.x + wSz.x, wPos.y + wSz.y),
                    GOLD_DIM, 16.0f, 0, 1.2f);

                DrawSidebar(winW);
                DrawContentArea(winW, winH);
            }
            End();

            PopStyleVar(4);
            PopStyleColor();
        }
    }
}



static void DrawToggleButton(bool cancelMode) {
    if (g_menu.isOpen) return;

    ImGuiIO& io = GetIO();
    static GLuint play_on_tex      = LoadTextureFromMemory(play_on_png,  play_on_png_len);
    static GLuint play_off_tex     = LoadTextureFromMemory(play_off_png, play_off_png_len);
    static GLuint queue_cancel_tex = LoadTextureFromMemory(play_on_png,  play_on_png_len);

    float button_size  = 130.f;
    float windowWidth  = button_size + GetStyle().WindowPadding.x * 2.0f;
    float windowHeight = button_size + GetStyle().WindowPadding.y * 2.0f;
    const float rightMargin = 20.0f;

    float fixedX = io.DisplaySize.x - rightMargin - windowWidth;

    SetNextWindowSize(ImVec2(windowWidth, windowHeight), ImGuiCond_Always);
    SetNextWindowPos(ImVec2(fixedX, g_sideBtnsY), ImGuiCond_Always);

    PushStyleColor(ImGuiCol_WindowBg, IM_COL32(0, 0, 0, 0));
    PushStyleColor(ImGuiCol_Border,   IM_COL32(0, 0, 0, 0));
    PushStyleVar(ImGuiStyleVar_WindowRounding, 99.0f);

    if (Begin(O("##ToggleBtn"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
              ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoMove)) {

        ImVec2 pos = GetCursorScreenPos();
        ImVec2 size(button_size, button_size);
        ImVec2 center(pos.x + size.x * 0.5f, pos.y + size.y * 0.5f);

        if (InvisibleButton(O("##TglBtnHit"), size)) {
            if (cancelMode) {
                persistent_bool[O("bAutoQueue")] = false;
                g_aqCounting = false;
            } else {
                AutoPlay::bAutoPlaying = !AutoPlay::bAutoPlaying;
                if (AutoPlay::bAutoPlaying) AutoPlay::ClearState();
            }
        }

        GLuint tex;
        if (cancelMode)                  tex = queue_cancel_tex;
        else if (AutoPlay::bAutoPlaying) tex = play_on_tex;
        else                             tex = play_off_tex;

        float r = size.x * 0.5f;
        ImDrawList* dl = GetWindowDrawList();
        dl->AddImage((void*)(intptr_t)tex,
            ImVec2(center.x - r, center.y - r),
            ImVec2(center.x + r, center.y + r));
    }
    End();
    PopStyleVar();
    PopStyleColor(2);
}




static void DrawFloatingButton(ImGuiIO& io) {
    if (g_menu.isOpen) return;

    static GLuint logo_tex = LoadTextureFromMemory(logo_png, logo_png_len);

    float buttonRadius = 65.0f;
    float winSize      = (buttonRadius * 2.0f) + 10.0f;
    const float rightMargin = 20.0f;

    if (g_sideBtnsY <= 0.0f) g_sideBtnsY = io.DisplaySize.y - 150.0f;

    float toggleWidth = 130.f + (GetStyle().WindowPadding.x * 2.0f);
    float fixedX = io.DisplaySize.x - rightMargin - toggleWidth + (toggleWidth - winSize) * 0.5f;
    float posY   = g_sideBtnsY - 140.0f;

    SetNextWindowPos(ImVec2(fixedX, posY), ImGuiCond_Always);
    SetNextWindowSize(ImVec2(winSize, winSize), ImGuiCond_Always);

    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
    PushStyleVar(ImGuiStyleVar_WindowPadding,    ImVec2(0, 0));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);

    if (Begin(O("##FloatBtn"), nullptr,
              ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoScrollbar |
              ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings)) {

        ImDrawList* dl = GetWindowDrawList();
        ImVec2 center  = ImVec2(fixedX + (winSize * 0.5f), posY + (winSize * 0.5f));

        InvisibleButton(O("##FloatBtnHit"), ImVec2(winSize, winSize));

        if (IsItemActive() && IsMouseDragging(ImGuiMouseButton_Left)) {
            g_sideBtnsY += io.MouseDelta.y;
            g_sideBtnsY  = ImClamp(g_sideBtnsY, 160.0f, io.DisplaySize.y - 150.0f);
        }

        if (IsItemHovered() && IsMouseReleased(0) && ImGui::GetMouseDragDelta(0).y == 0.0f) {
            g_menu.isOpen = true;
        }

        dl->AddImage((void*)(intptr_t)logo_tex,
            ImVec2(center.x - buttonRadius, center.y - buttonRadius),
            ImVec2(center.x + buttonRadius, center.y + buttonRadius));
    }
    End();
    PopStyleVar(2);
    PopStyleColor();
}



static bool first_time = true;
INLINE void DrawLogin(ImGuiIO& io) {
    if (logged_in) return DrawMenu(io);


    SetNextWindowPos(ImVec2(0, 0));
    SetNextWindowSize(io.DisplaySize);
    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.04f, 0.04f, 0.04f, 0.96f));
    Begin(O("##Overlay"), nullptr,
        ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoInputs | ImGuiWindowFlags_NoBringToFrontOnFocus);
    End();
    PopStyleColor();


    float cardW = 580.0f;
    float cardH = 420.0f;

    SetNextWindowSize(ImVec2(cardW, cardH), ImGuiCond_Always);
    SetNextWindowPos(ImVec2(io.DisplaySize.x * 0.5f, io.DisplaySize.y * 0.5f),
        ImGuiCond_Always, ImVec2(0.5f, 0.5f));

    PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.07f, 0.07f, 0.07f, 1.0f));
    PushStyleColor(ImGuiCol_Border,   ImVec4(0.83f, 0.67f, 0.16f, 1.0f));
    PushStyleVar(ImGuiStyleVar_WindowRounding,   20.0f);
    PushStyleVar(ImGuiStyleVar_WindowPadding,    ImVec2(0, 0));
    PushStyleVar(ImGuiStyleVar_WindowBorderSize, 1.5f);

    if (Begin(O("##LoginCard"), nullptr,
        ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize |
        ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoScrollbar)) {

        ImDrawList* dl  = GetWindowDrawList();
        ImVec2 winPos   = GetWindowPos();


        dl->AddRectFilledMultiColor(
            winPos,
            ImVec2(winPos.x + cardW, winPos.y + 110),
            IM_COL32( 18,  14,   2, 255),
            IM_COL32( 50,  40,   5, 255),
            IM_COL32( 80,  62,   8, 255),
            IM_COL32( 18,  14,   2, 255)
        );
        dl->AddRectFilled(winPos, ImVec2(winPos.x + cardW, winPos.y + 20),
            IM_COL32(18, 14, 2, 255), 20.0f, ImDrawFlags_RoundCornersTop);

        dl->AddLine(
            ImVec2(winPos.x, winPos.y + 110),
            ImVec2(winPos.x + cardW, winPos.y + 110),
            GOLD_DIM, 1.0f
        );

        SetWindowFontScale(1.4f);
        ImVec2 titleSize = CalcTextSize(O("ZeroTrace"));
        dl->AddText(ImVec2(winPos.x + (cardW - titleSize.x) * 0.5f, winPos.y + 30),
            GOLD_BRIGHT, O("Your Name"));
        SetWindowFontScale(1.0f);

        ImVec2 subSize = CalcTextSize(O("Premium Mod"));
        dl->AddText(ImVec2(winPos.x + (cardW - subSize.x) * 0.5f, winPos.y + 70),
            GREY_TEXT, O("Premium Mod"));

        SetCursorPosY(130);

        if (!ERROR_MESSAGE.empty()) {
            SetCursorPosX(30);
            PushTextWrapPos(cardW - 30);
            TextColored(ImVec4(1.0f, 0.35f, 0.2f, 1.0f), "%s", ERROR_MESSAGE.c_str());
            PopTextWrapPos();
            Dummy(ImVec2(0, 15));
        }

        if (is_logging_in) {
            SetCursorPosY(180);

            static float spinner_angle = 0.0f;
            spinner_angle += io.DeltaTime * 5.0f;

            float spinner_size = 40.0f;
            ImVec2 spinnerCenter = ImVec2(winPos.x + cardW * 0.5f, winPos.y + 220);

            for (int i = 0; i < 12; i++) {
                float angle = spinner_angle + (i * PI * 2.0f / 12.0f);
                float alpha = (float)(12 - i) / 12.0f;
                ImVec2 dotPos = ImVec2(
                    spinnerCenter.x + cosf(angle) * spinner_size,
                    spinnerCenter.y + sinf(angle) * spinner_size
                );
                dl->AddCircleFilled(dotPos, 6.0f, IM_COL32(212, 170, 40, (int)(alpha * 255)));
            }

            ImVec2 loadingSize = CalcTextSize(O("Authenticating..."));
            SetCursorPosX((cardW - loadingSize.x) * 0.5f);
            SetCursorPosY(290);
            TextColored(GREY_GOLD_VEC4, O("Authenticating..."));
        } else {
            SetCursorPosY(160);

            ImVec2 infoSize = CalcTextSize(O("Copy your license key and tap login"));
            SetCursorPosX((cardW - infoSize.x) * 0.5f);
            TextColored(GREY_GOLD_VEC4, O("Copy your license key and tap login"));

            Dummy(ImVec2(0, 50));

            bool AutoLogin = first_time && !persistent_string["key"].empty();

            SetCursorPosX(40);

            PushStyleColor(ImGuiCol_Button,        GOLD_DIM_VEC4);
            PushStyleColor(ImGuiCol_ButtonHovered, GOLD_VEC4);
            PushStyleColor(ImGuiCol_ButtonActive,  ImVec4(0.45f, 0.34f, 0.04f, 1.0f));
            PushStyleColor(ImGuiCol_Text,          ImVec4(0.05f, 0.05f, 0.05f, 1.0f));
            PushStyleVar(ImGuiStyleVar_FrameRounding, 14.0f);

            if (AutoLogin || Button(O("##LoginBtn"), ImVec2(cardW - 80.0f, 65.0f))) {
                if (DEBUG_BYPASS_LOGIN) {
                    logged_in = true;
                    g_menu.isOpen = true;
                } else {
                    JNIEnv* env;
                    jint getEnvResult = VM->GetEnv((void**)&env, JNI_VERSION_1_6);
                    if (getEnvResult == JNI_EDETACHED) {
                        if (VM->AttachCurrentThread(&env, nullptr) != 0)
                            ERROR_MESSAGE = O("Failed to attach thread to JVM");
                    } else if (getEnvResult != JNI_OK) {
                        ERROR_MESSAGE = O("Failed to get JNIEnv");
                    } else {
                        std::thread([](std::string androidId, std::string key) {
                            Login(androidId, key);
                        }, getAndroidID(env),
                           AutoLogin ? persistent_string["key"] : getClipboard(env)).detach();
                    }
                    first_time = false;
                }
            }

            PopStyleVar();
            PopStyleColor(4);

            Dummy(ImVec2(0, 35));

            ImVec2 helpSize = CalcTextSize(O("Your will read"));
            SetCursorPosX((cardW - helpSize.x) * 0.5f);
            TextColored(GOLD_DIM_VEC4, O("Your will read"));
        }
    }
    End();
    PopStyleVar(3);
    PopStyleColor(2);
}


INLINE void SetupImgui() {
    PACKAGE_NAME = string(getcmdline());

    ImGui::CreateContext();

    auto& style = ImGui::GetStyle();
    auto& io    = ImGui::GetIO();

    io.ConfigFlags |= ImGuiConfigFlags_IsTouchScreen;

    switch_theme(current_theme);

    load_persistence();
    svConfig_Load();
    load_imgui_style();

    static string INI_PATH = O("/data/user_de/0/") + PACKAGE_NAME + O("/no_backup/.ini");
    io.IniFilename = persistent_bool["bImguiAutoSave"] ? INI_PATH.c_str() : nullptr;
    io.ConfigWindowsMoveFromTitleBarOnly = persistent_bool["bMoveOnlyWithTitleBar"];

    ImFontConfig font_cfg;
    font_cfg.SizePixels = persistent_float["fFontScale"];
    io.Fonts->AddFontDefault(&font_cfg);

    
    
    {
        const char* arFonts[] = {
            "/system/fonts/NotoNaskhArabic-Regular.ttf",
            "/system/fonts/NotoNaskhArabicUI-Regular.ttf",
            "/system/fonts/NotoSansArabic-Regular.ttf",
            "/system/fonts/DroidNaskh-Regular.ttf",
            "/system/fonts/DroidSansArabic.ttf",
            "/system/fonts/Roboto-Regular.ttf",
        };
        ImFontConfig arCfg;
        arCfg.MergeMode    = true;
        arCfg.PixelSnapH   = true;
        arCfg.SizePixels   = persistent_float["fFontScale"];
        const ImWchar* arRanges = GetArabicGlyphRanges();
        for (int i = 0; i < (int)(sizeof(arFonts)/sizeof(arFonts[0])); i++) {
            FILE* tf = fopen(arFonts[i], "rb");
            if (!tf) continue;
            fclose(tf);
            io.Fonts->AddFontFromFileTTF(arFonts[i], persistent_float["fFontScale"], &arCfg, arRanges);
            break;
        }
        io.Fonts->Build();
    }

    ImGui_ImplAndroid_Init();
    ImGui_ImplOpenGL3_Init(O("#version 300 es"));

    bImguiSetup = true;
}

DEFINES(EGLBoolean, Draw, EGLDisplay dpy, EGLSurface surface) {
    eglQuerySurface(dpy, surface, EGL_WIDTH,  &Width);
    eglQuerySurface(dpy, surface, EGL_HEIGHT, &Height);

    if (Width <= 0 || Height <= 0) return _Draw(dpy, surface);

    screenCenter = Vector2(Width / 2, Height / 2);

    if (!bImguiSetup) SetupImgui();

    ImGuiIO& io = ImGui::GetIO();

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(Width, Height);
    ImGui::NewFrame();

    if (!is_segv_handler_active()) setup_global_segv_handler();

    if (IsExpired()) {
        DrawExpired(io);
    } else if ((!g_Token.empty() && !g_Auth.empty() && g_Token == g_Auth) || DEBUG_BYPASS_LOGIN) {
        bool hideAll = persistent_bool[O("bHideAllCapture")];
        if (!hideAll) {
            DrawFloatingButton(io);
            DrawMenu(io);

            {
                SetNextWindowPos(ImVec2(Width * 0.5f, Height - 60.0f), ImGuiCond_Always, ImVec2(0.5f, 1.0f));
                Begin(O("##PoweredBy"), nullptr,
                    ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                    ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
                    ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_AlwaysAutoResize |
                    ImGuiWindowFlags_NoInputs);
                TextColored(GOLD_VEC4, O("Owner By @olv8pool"));
                End();
            }

            if (g_autoPlayCalculating) DrawCalculating();
        } else {
            
            SetNextWindowPos(ImVec2(0, 0), ImGuiCond_Always);
            SetNextWindowSize(ImVec2(120.0f, 120.0f), ImGuiCond_Always);
            PushStyleColor(ImGuiCol_WindowBg, ImVec4(0, 0, 0, 0));
            PushStyleVar(ImGuiStyleVar_WindowBorderSize, 0.0f);
            PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
            if (Begin(O("##CaptureRecover"), nullptr,
                ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoScrollbar |
                ImGuiWindowFlags_NoBackground | ImGuiWindowFlags_NoCollapse)) {
                if (InvisibleButton(O("##CaptureRecoverBtn"), ImVec2(120.0f, 120.0f))) {
                    persistent_bool[O("bHideAllCapture")] = false;
                }
            }
            End();
            PopStyleVar(2);
            PopStyleColor();
        }
    } else {
        DrawLogin(io);
    }

    ImGui::EndFrame();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    ImGui_ClearHoverEffect();

    return _Draw(dpy, surface);
}

void __IMGUI__() {
    create_directory_recursive(CONC(O("/data/user_de/0/"), PACKAGE_NAME.c_str(), O("/no_backup")));
}
